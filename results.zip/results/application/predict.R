# same seed as R 3.5.1 (used in Julia)
RNGkind(sample.kind = "Rounding")
# RNGkind(sample.kind = "default")

mainwd = "YOUR_PATH"
setwd(mainwd)


# proportion of points in the training set
# punit = 0.80
punit = 0.90
par(mfrow=c(4,4))
#-------------------------------------------------------------------------
# Load necessary package
#-------------------------------------------------------------------------
library(MASS)
library(robustbase)
library(glmnet)

#-------------------------------------------------------------------------
# helpful function
#-------------------------------------------------------------------------
standR <- function(x){
  x1 = t(t(x) - colMedians(x))
  x = t(t(x1) / apply(x, 2, mad))
  return(x)
}
predtrim <- function(x,y,b,r){
	nt = dim(x)[1]
	kn = round(floor(nt*r),1)
	all = (y-x%*%b)^2
  trim = all[order(all)][1:kn]
  rmspe = median(trim)
	return(rmspe)
}
predscale <- function(xt,yt,xn,yn,b,phi){
  ntr = dim(xt)[1] - sum(phi==0)
	phi = as.logical(phi)
	restr = yt[phi]-xt[phi,]%*%b
	str = sqrt(sum(restr^2)/ntr)
	reste = (yn-xn%*%b)/str
	plot(xn%*%b, yn)
	ste = mad(reste)
	abline(0,1)
	idx = which(abs(reste) > 1.345*ste)
	testerr = mean(reste[-idx]^2)
	NteClean = dim(xn)[1] - length(idx)
	all = data.frame(testerr=testerr,NteClean = NteClean)
	return(all)
}
#-------------------------------------------------------------------------
# load data
#-------------------------------------------------------------------------
compall <- function(typeDat,intercept,seed,R){
  
  setwd(mainwd)
  setwd("./results/application")
  
	if (typeDat == "glass"){
		load("glass.RData") 
		Xall = as.matrix(x[, 15:500])
		if (intercept == 1){
			Xall = cbind(rep(1, nrow(Xall)), Xall)  
		}
		Yall = y[, colnames(y) == "PbO"]
		d = dim(Xall)[2]
		nall = dim(Xall)[1]
		set.seed(seed)
		N = floor(punit*nall)
		idx = sample(1:nall,N,replace=FALSE)
		X = Xall[idx,]
		Y = Yall[idx]
		Xtest = Xall[-idx,]
		Ytest = Yall[-idx]
	} else if (typeDat == "childoral"){
		load("microbiomefixlogno0mad.Rdata")
		Xall = as.matrix(data_childoral[,-c(1, 24, 70, 6)])
		if (intercept == 1){
			Xall = cbind(1, Xall)
		}
		Yall = data_childoral$Y
		d = dim(Xall)[2]
		nall = dim(Xall)[1]
		set.seed(seed)
		N = floor(punit*nall)
		idx = sample(1:nall,N,replace=FALSE)
		X = Xall[idx,]
		Y = Yall[idx]
		Xtest = Xall[-idx,]
		Ytest = Yall[-idx]
	} else if (typeDat == "childgut"){
		load("microbiomefixlogno0mad.Rdata")
		Xall = as.matrix(data_childgut[,-1])
		if (intercept == 1){
			Xall = cbind(1, Xall)
		}
		Yall = data_childgut$Y
		d = dim(Xall)[2]
		nall = dim(Xall)[1]
		set.seed(seed)
		N = floor(punit*nall)
		idx = sample(1:nall,N,replace=FALSE)
		X = Xall[idx,]
		Y = Yall[idx]
		Xtest = Xall[-idx,]
		Ytest = Yall[-idx]
	} else if (typeDat == "momoral"){
		load("microbiomefixlogno0mad.Rdata")
		Xall = as.matrix(data_momoral[,-c(1,32, 45, 34)])
		if (intercept == 1){
			Xall = cbind(1, Xall)
		}
		Yall = data_momoral$Y
		d = dim(Xall)[2]
		nall = dim(Xall)[1]
		set.seed(seed)
		N = floor(punit*nall)
		idx = sample(1:nall,N,replace=FALSE)
		X = Xall[idx,]
		Y = Yall[idx]
		Xtest = Xall[-idx,]
		Ytest = Yall[-idx]
	}else {
		print("Option not available")
	}
	persp=0
	#-------------------------------------------------------------------------
	# compare with regular LASSO
	#-------------------------------------------------------------------------
	mod = cv.glmnet(X[,-1],Y,alpha=1,nfolds=10,nlambda=100)
	Blasso = coef(mod,s=mod$lambda.min)
	setwd(mainwd)
	setwd("./results/application")
	if (punit==0.8) {
	  setwd("./20trim_CO_MO_pred")
	} else if (punit==0.9){
	  setwd("./20trim_CO_MO_pred_90train")
	}
	# load results
	B =	read.csv(paste(N, d, R, seed,typeDat,"check","B_est.csv",sep="-"))
	  # resss=Ytest-Xtest%*%B[,3]
	  # plot(resss)
	  # abline(0, 0, col="red")
	  # aaa=1:length(Y)
	  # points(aaa[Phi[,3]==0], resss[as.logical(Phi[,3]==0)], col="red")
	Phi = read.csv(paste(N, d, R, seed,typeDat,"check","Phi_est.csv",sep="-"))
	B$lasso = as.numeric(Blasso)
	Phi$lasso = rep(1,N)
  	resss=Y-X%*%B[,3]
  	plot(resss)
  	abline(0, 0, col="red")
  	aaa=1:length(Y)
  	points(aaa[Phi[,3]==0], resss[as.logical(Phi[,3]==0)], col="red")
	#-------------------------------------------------------------------------
	# get scaled prediction
	#-------------------------------------------------------------------------
	Prediction = matrix(NA,dim(B)[2], 1)
	CleanSize = matrix(NA,dim(B)[2], 1)# vector(NA,length=dim(B)[2])
	BSize = matrix(NA,dim(B)[2], 1)# vector(NA,length=dim(B)[2])
	for(i in 1:dim(B)[2]){
	  rr = 0.5
	  all = predtrim(Xtest,Ytest,B[,i],1-rr)
		Prediction[i] = all #all$testerr
		CleanSize[i] = (1-rr)*dim(Xtest)[1] #all$NteClean
		BSize[i] = sum(abs(B[,i])>=0.00001)
	}
	all = data.frame(Prediction=Prediction,CleanSize=CleanSize,BSize=BSize)
	return(all)
}


#-------------------------------------------------------------------------
# loop through data and reps
#-------------------------------------------------------------------------
typeDat = c("childoral","momoral")
seed = 2020:2027
R = 0.2
intercept = 1
predall = list();
cleansizeall = list();
bsizeall = list();
predmeans = matrix(NA,nrow=length(typeDat),ncol=4)
predsd = matrix(NA,nrow=length(typeDat),ncol=4)
cleansizemeans = matrix(NA,nrow=length(typeDat),ncol=4)
cleansizesd = matrix(NA,nrow=length(typeDat),ncol=4)
bsizemeans = matrix(NA,nrow=length(typeDat),ncol=4)
bsizesd = matrix(NA,nrow=length(typeDat),ncol=4)
for(t in 1:length(typeDat)){
	print(typeDat[t])
	predall[[t]] = matrix(NA,nrow=length(seed),ncol=4)
	cleansizeall[[t]] = matrix(NA,nrow=length(seed),ncol=4)
	bsizeall[[t]] = matrix(NA,nrow=length(seed),ncol=4)
	for(s in 1:length(seed)){
		all = compall(typeDat[t],intercept,seed[s],R)
		predall[[t]][s,] = all$Prediction
		cleansizeall[[t]][s,] = all$CleanSize
		bsizeall[[t]][s,] = all$BSize
	}
	predmeans[t,] = colMedians(predall[[t]])
	predsd[t,] = (apply(predall[[t]],2,mad))/sqrt(length(seed))
	cleansizemeans[t,] = colMedians(cleansizeall[[t]])
	cleansizesd[t,] = apply(cleansizeall[[t]],2,mad)/sqrt(length(seed))
	bsizemeans[t,] = colMedians(bsizeall[[t]])
	bsizesd[t,] = apply(bsizeall[[t]],2,mad)/sqrt(length(seed))
}

predmeans
predsd

bsizemeans
bsizesd

# cleansizemeans
# cleansizesd

ndig = 2
predmeans = format(round(predmeans[,1:ncol(predmeans)], digits=ndig), nsmall=ndig)
predsd = format(round(predsd[,1:ncol(predsd)], digits=ndig), nsmall=ndig)
bsizemeans = format(round(bsizemeans[,1:ncol(bsizemeans)], digits=ndig), nsmall=ndig)
bsizesd = format(round(bsizesd[,1:ncol(bsizesd)], digits=ndig), nsmall=ndig)

dfMM = predmeans
dfBB = bsizemeans
for (i in 1:nrow(dfMM)){
  for(j in 1:ncol(dfMM)){
    dfMM[i,j] = paste0(as.character(predmeans[i,j]), "(", as.character(predsd[i,j]), ")")
    dfBB[i,j] = paste0(as.character(bsizemeans[i,j]), "(", as.character(bsizesd[i,j]), ")")
  }
}

aSol = cbind.data.frame(t(dfMM), t(dfBB))
sol = aSol[, c(1,3)]
sol2 = aSol[, c(2,4)]
names(sol2) = c("1", "1.1")
sol = rbind.data.frame(sol, sol2)

require(xtable)
print(xtable(sol, digits=ndig))
