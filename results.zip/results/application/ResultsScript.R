if(!require(ggplot2)){install.packages("ggplot2"); library(ggplot2)}
if(!require(MASS)){install.packages("MASS"); library(MASS)}
if(!require(gridExtra)){install.packages("gridExtra"); library(gridExtra)}

mainwd = "YOUR_PATH"
setwd(mainwd)
setwd("./results/application")

load("microbiomefixlogno0mad.Rdata")
load("allID.Rdata")

# index of the features to remove with 48% or more 0s
names(data_momoral) = 1:ncol(data_momoral)
sort(colSums(data_momoral == 0)/nrow(data_momoral))
names(data_childoral) = 1:ncol(data_childoral)
sort(colSums(data_childoral == 0)/nrow(data_childoral))

Y.co = data_childoral[,1]
hist(Y.co, 50)
Y.mo = data_momoral[,1]
hist(Y.mo, 50)

CO = cbind.data.frame(rep(1, length(Y.co)), data_childoral[,2:ncol(data_childoral)])
CO = CO[,-c(24, 70, 6)] 
MO = cbind.data.frame(rep(1, length(Y.mo)), data_momoral[,2:ncol(data_momoral)])
MO = MO[,-c(32, 45, 34)]

setwd("./20trim_CO_MO")
frcont = 0.2
B.co = read.csv(paste0("215-68-", frcont, "-0-childoral-check-B_est.csv"))
B.mo = read.csv(paste0("215-63-",frcont, "-0-momoral-check-B_est.csv"))
P.co = read.csv(paste0("215-68-", frcont , "-0-childoral-check-Phi_est.csv"))
P.mo = read.csv(paste0("215-63-", frcont, "-0-momoral-check-Phi_est.csv"))

# total features selected
colSums(B.co!=0)
colSums(B.mo!=0)
Yco = Y.co
Xco = as.matrix(CO)
Ymo = Y.mo
Xmo = as.matrix(MO)


for (ij in 1:2) {

  if (ij==1) {
      ###########################################
      # CO
      
      idx = which(P.co$mipIC==0)
      Y = Y.co
      X = as.matrix(CO)
      b = B.co$mipIC
      
      ind = which(b!=0)
      indbin = P.co$mipIC
      idxCO = indbin
      
      # plot(X[,ind[2]], Y)
      # abline(a=b[ind[1]], b=b[ind[2]])
      # points(X[idx,ind[2]], Y[idx], col = "red")
      # 
      # my_cols <- c("#FC4E07", "#00AFBB")
      # pairs(cbind.data.frame(Y, X[,ind[2:length(ind)]]), pch = 19,  cex = 1.5,
      #       # col = my_cols[P.cg$x3+1],
      #       col = my_cols[P.co$mipIC+1],
      #       lower.panel=NULL)
      
      # tit = paste0(getwd(), "/datMO05.csv")
      # write.table(cbind.data.frame(Y, X[,ind[2:length(ind)]], P.co$mipIC), row.names=FALSE, col.names=T, tit)
      
  } else if (ij==2){
      ############################################
      # MO
      
      idx = which(P.mo$x3==0)
      idx = which(P.mo$mipIC==0)
      Y = Y.mo
      X = as.matrix(MO)
      
      b = B.mo$x3
      b = B.mo$mipIC
      
      ind = which(b!=0)
      indbin = P.mo$x3
      indbin = P.mo$mipIC
      idxMO = indbin
      
      # # my_cols <- c("#FC4E07", "#00AFBB")
      # # pairs(cbind.data.frame(Y, X[,ind[2:length(ind)-1]]), pch = 19,  cex = 1.5,
      # #       col = my_cols[P.mo$x3+1],
      # #       lower.panel=NULL)
      # my_cols <- c("#FC4E07", "#00AFBB")
      # pairs(cbind.data.frame(Y, X[,ind[2:length(ind)]]), pch = 19,  cex = 1.5,
      #       col = my_cols[P.mo$mipIC+1],
      #       lower.panel=NULL)
      # plot(X[,ind[2]], Y, pch = 19,  cex = 1.5)
      # # plot(X[,ind[2]], Y, pch = 19,  cex = 1.5)
      # # which(X[,ind[2]] == max(X[,ind[2]]))
      # # idxOut
      
      # tit = paste0(getwd(), "/datMO10.csv")
      # write.table(cbind.data.frame(Y, X[,ind[2:6]], P.mo$x3), row.names=FALSE, col.names=T, tit)
      
  }
  ########################################
  
  Xt = X
  colnames(Xt) = 1:ncol(Xt)
  # corrplot(cor(Xt[,2:ncol(Xt)]))
  
  summary(lm(Y[-idx]~Xt[-idx,ind]-1))
  b = coefficients(lm(Y[-idx]~Xt[-idx,ind[2:length(ind)]]))
  
  Ypred = X[,ind] %*% b
  # plot(Y, Ypred)
  # points(Y[idx], Ypred[idx], col = "red")
  # abline(0, 1, col="green")
  
  Res = (Ypred-Y)
  resmean = mean(Res[-idx])
  resstd = sd(Res[-idx])
  Res = (Res-resmean)/resstd
  
  require("car")
  # qqPlot(Res)
  

  if (ij==1) {
    resCO = Res
  } else if (ij==2){
    resMO = Res
  }



  if (ij==2) {
    # Web Figure 1 - left
    require(gridExtra)
    par(mfrow=c(1,2))
    plot1 <- qqPlot(resCO, ylab="CO standardised residuals")
    plot2 <- qqPlot(resMO, ylab="MO standardised residuals")
  }
  
}




# Run it uncommenting CO or MO
Res = resCO
indbin = idxCO
# Res = resMO
# indbin = idxMO

graph = data.frame(Y=Res,
                   X = 1:length(Res),
                   type = indbin) 
idxx = which(graph$type==1)
graph$type[idxx] = "Non-outlying"
graph$type[-idxx] = "Outlying"
p1 = ggplot(graph, aes(x=X, y=Y, shape=type, color=type)) +
  theme_bw() +
  geom_point(size=2) +
  geom_hline(yintercept=0,linetype="dashed", 
             color = "black", size=1.5) + 
  labs(title="") +
  xlab("Observation Index") + ylab("Standardized Residuals") +
  theme(
    plot.title = element_text(size=14, face="bold"),
    axis.title.x = element_text(size=14, face="bold"),
    axis.title.y = element_text(size=14, face="bold"),
    axis.text.x = element_text(size=14,face="bold"),
    axis.text.y = element_text(size=14,face="bold"),
    legend.title = element_blank()
  )
p1


# align data with IDs
ResCO = resCO
ResMO = resMO

idM = match(IDs_Mbuccal, IDs_Cbuccal)
ResCOs = ResCO[idM]
ResCOs[is.na(ResCOs)] = ResCO[is.na(ResCOs)]
  
ResCO = ResCOs

idxCOs = idxCO[idM]
idxCOs[is.na(idxCOs)] = idxCO[is.na(idxCOs)]
idxCO=idxCOs

######################################################
# Web Figure 2
######################################################
graph = data.frame(Y=ResCO,
                   X = ResMO,
                   type = rep(0, length(Res)),
                   type1 = idxMO,
                   type2 = idxCO)
idxx = which(graph$type1==1 & graph$type2==1)
idxxMO = which(graph$type1==1 & graph$type2==0)
idxxCO = which(graph$type1==0 & graph$type2==1)
idxxB = which(graph$type1==0 & graph$type2==0)
graph$type[idxx] = "Non-outlying"
graph$type[idxxMO] = "CO Outlying"
graph$type[idxxCO] = "MO Outlying"
graph$type[idxxB] = "Both Outlying"
p1 = ggplot(graph, aes(x=X, y=Y, shape=type, color=type)) +
  theme_bw() +
  geom_point(size=2) +
  geom_hline(yintercept=0,linetype="dashed", 
             color = "black", size=0.5) + 
  geom_vline(xintercept=0,linetype="dashed", 
             color = "black", size=0.5) +
  xlab("MO standardised residuals") + ylab("CO standardised residuals") +
  theme(
    plot.title = element_text(size=14, face="bold"),
    axis.title.x = element_text(size=14, face="bold"),
    axis.title.y = element_text(size=14, face="bold"),
    axis.text.x = element_text(size=14,face="bold"),
    axis.text.y = element_text(size=14,face="bold"),
    legend.title = element_blank(),
    legend.position = c(0.82, 0.2),
    legend.text = element_text(size=12),
    legend.background = element_rect(fill="white",
                                     size=0.5, linetype="solid", 
                                     colour ="black")
  )
p1



require(rrcov)

XX = scale(X[,ind[2:length(ind)]])
mcd <- rrcov::CovMcd(XX, alpha = 1-frcont, nsamp="best")
# get mcd estimate of location
mean_mcd <- mcd@raw.center
# get mcd estimate scatter
cov_mcd <- mcd@raw.cov

# get inverse of scatter
cov_mcd_inv <- solve(cov_mcd)

# compute the robust distance
robust_dist <- apply(XX, 1, function(x){
  x <- (x - mean_mcd)
  dist <- sqrt((t(x)  %*% cov_mcd_inv %*% x))
  return(dist)
})

# set cutoff using chi square distribution
threshold <- sqrt(qchisq(p = 0.95, df = ncol(XX)))

# find outliers
outliers <-  which(robust_dist >= threshold)
sum(outliers %in% idx)

######################################################
# Web Figure 3: run it twice with CO and MO data
######################################################
levv = robust_dist >= threshold
typpp = rep(0, length(levv))
typpp[(indbin == 1) & (levv ==1)] = "NO-L"
typpp[(indbin == 1) & (levv ==0)] = "NO-NL"
typpp[(indbin == 0) & (levv ==1)] = "O-L"
typpp[(indbin == 0) & (levv ==0)] = "O-NL"

graph = data.frame(Y=Res,
                   X = robust_dist,
                   type = indbin,
                   typpp = typpp,
                   lev = levv)
idxx = which(graph$type==1)
graph$type[idxx] = "Non-outlying"
graph$type[-idxx] = "Outlying"
p1 = ggplot(graph, aes(x=X, y=Y, shape=typpp, color=typpp)) +
  theme_bw() +
  geom_point(size=2) +
  geom_hline(yintercept=0,linetype="dashed", 
             color = "black", size=1.5) + 
  xlab("Robust distance in X (MCD)") + ylab("MO standardised residuals") +
  theme(
    plot.title = element_text(size=14, face="bold"),
    axis.title.x = element_text(size=14, face="bold"),
    axis.title.y = element_text(size=14, face="bold"),
    axis.text.x = element_text(size=14,face="bold"),
    axis.text.y = element_text(size=14,face="bold"),
    legend.title = element_blank(),
    legend.position = c(0.82, 0.8),
    legend.text = element_text(size=12),
    legend.background = element_rect(fill="white",
                                     size=0.5, linetype="solid", 
                                     colour ="black")
  ) 
p1


######################################################
# Web Figure 1 - right
######################################################
intersect.id = intersect(IDs_Cbuccal,IDs_Mbuccal)
check = vector(,length=length(intersect.id))
check2 = check
for(i in 1:length(intersect.id)){
  check[i] = Y.co[which(IDs_Cbuccal==intersect.id[i])]
  check2[i] = Y.mo[which(IDs_Mbuccal==intersect.id[i])]
}
sum(check!=check2)

outlier.co = IDs_Cbuccal[which(P.co$mipIC==0)]
outlier.mo = IDs_Mbuccal[which(P.mo$mipIC==0)]
length(intersect(outlier.co,outlier.mo))
length(outlier.co %in% IDs_Mbuccal)
length(outlier.mo %in% IDs_Cbuccal)

outliers.all = rep("Non-outlying",215)
outliers.all[which(P.co$mipIC==0)] = "CO Outlying"
idx = which(IDs_Cbuccal %in% outlier.mo)
outliers.all[idx] = "MO Outlying"
idx = which(IDs_Cbuccal %in% intersect(outlier.co,outlier.mo))
outliers.all[idx] = "Both Outlying"
data = data.frame(Y = Y.co,outliers = outliers.all,type="CO")
data$outliers = factor(data$outliers,
                       levels = c("Both Outlying",
                                  "CO Outlying",
                                  "MO Outlying",
                                  "Non-outlying"))
p <- ggplot(data, aes(x=type,y=Y)) + 
  geom_violin() +
  geom_boxplot(width=0.1)+
  theme_bw() +
  geom_jitter(position=position_jitter(0.2), size = 2,aes(colour = factor(outliers),shape=factor(outliers))) +
  #scale_colour_manual(name="", values=c("#636363", "#3182bd", "#31a354","#e6550d")) +
  xlab("") + ylab("Conditional Weight Gain") +
  theme(
    plot.title = element_text(size=14, face="bold"),
    axis.title.x = element_blank(), #element_text(size=14, face="bold"),
    axis.title.y = element_text(size=14, face="bold"),
    axis.text.x = element_blank(),
    axis.text.y = element_text(size=14,face="bold")
  ) +
  theme(#legend.position ="none",
    legend.title = element_blank(),
    legend.text = element_text(size=14),
    strip.text = element_text(size = 14))
p
