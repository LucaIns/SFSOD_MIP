
#######################################################################################
# Create table for LaTex
#######################################################################################
# require(robustbase)
if(!require(xtable)){install.packages("xtable"); library(xtable)}

# main path to the extracted zip folder
mainwd = "YOUR_PATH"


# robust results for 0 (median, MAD) or non.robust for 1 (mean, sd)
robres = 0
# number of significant digits
ndig = 2
# dataset (1: main results, 2: lower SNR, 3: collinerity)
# note that only 1 has a 1000 replications
dataset = 1


for (ij in 1:2) {
    
  # sample sizes to extract
  selCases = c(50, 100, 150)
  
  setwd(mainwd)
  setwd("./results/simulation")   
  if (dataset == 1) {
    setwd("./SNR_5_1000rep/merged")  
  } else if (dataset == 2){
    setwd("./SNR_3")  
  } else if (dataset == 3){
    setwd("./corr")  
  }
  setwd("./low")  

  fl = list.files()[grepl("OUT.csv", list.files())]
  fl[1]
  nparam = ncol(read.csv(fl[1])) 
  #nparam = ncol(read.csv(fl[length(fl)])) 
  sol = as.data.frame(matrix(NA, length(fl), nparam))
  cont = rep(NA, length(fl))
  n = rep(NA, length(fl))
  p = rep(NA, length(fl))
  k_s = rep(NA, length(fl))
  for (i in 1:length(fl)) {
    n[i] = strsplit(fl, "-")[[i]][1]
    cont[i] = strsplit(fl, "-")[[i]][4]
    p[i] = strsplit(fl, "-")[[i]][2]
    k_s[i] = strsplit(fl, "-")[[i]][3]
    if (ij == 1) {
      if (robres==1) {
        sol[i,] = colMedians(as.matrix(read.csv(fl[i])))  
      } else{
        sol[i,] = colMeans(read.csv(fl[i]))
      }
    } else {
      if (robres==1) {
        sol[i,] = apply(read.csv(fl[i]), 2, mad)
      } else{
        sol[i,] = apply(read.csv(fl[i]), 2, sd)
      }
    }
  }
  colnames(sol) = colnames(read.csv(fl[i]))
  # subsect
  indN = as.numeric(n) %in% selCases
  n = n[indN]
  p = p[indN]
  sol = sol[indN, ]
  # sorting
  ind_res = order(as.numeric(n))
  n = n[ind_res]
  solN = sol[ind_res, ]
  solN = cbind.data.frame(n, p, solN)
  
  # load p
  # sizes to extract
  selCases = c(200)
  
  setwd(mainwd)
  setwd("./results/simulation")   
  if (dataset == 1) {
    setwd("./SNR_5_1000rep/merged")  
  } else if (dataset == 2){
    setwd("./SNR_3")  
  } else if (dataset == 3){
    setwd("./corr")  
  }
  setwd("./high")
  
  fl = list.files()[grepl("OUT.csv", list.files())]
  nparam = ncol(read.csv(fl[1]))
  sol = as.data.frame(matrix(NA, length(fl), nparam))
  cont = rep(NA, length(fl))
  n = rep(NA, length(fl))
  p = rep(NA, length(fl))
  k_s = rep(NA, length(fl))
  for (i in 1:length(fl)) {
    n[i] = strsplit(fl, "-")[[i]][1]
    cont[i] = strsplit(fl, "-")[[i]][4]
    p[i] = strsplit(fl, "-")[[i]][2]
    k_s[i] = strsplit(fl, "-")[[i]][3]
    if (ij == 1) {
      if (robres==1) {
        sol[i,] = colMedians(as.matrix(read.csv(fl[i])))  
      } else{
        sol[i,] = colMeans(read.csv(fl[i]))
      }
    } else {
      if (robres==1) {
        sol[i,] = apply(read.csv(fl[i]), 2, mad)
      } else{
        sol[i,] = apply(read.csv(fl[i]), 2, sd)
      }
    }
  }
  colnames(sol) = colnames(read.csv(fl[i]))
  # subsect
  indP = as.numeric(p) %in% selCases
  n = n[indP]
  p = p[indP]
  sol = sol[indP, ]
  # sorting
  ind_res = order(as.numeric(n))
  p = p[ind_res]
  n = n[ind_res]
  solP = sol[ind_res, ]
  solP = cbind.data.frame(n, p, solP)
  
  # merging
  sol = rbind.data.frame(solN, solP)
  n = sol[,1]
  p = sol[, 2]
  sol = sol[, 3:ncol(sol)]
  
  # fix structure
  est_nam = unlist(unique(lapply(strsplit(colnames(sol), "_"), `[[`, 1)))
  # capitalize first letter
  simpleCap <- function(x) {
    s <- strsplit(x, " ")[[1]]
    paste(toupper(substring(s, 1,1)), substring(s, 2),
          sep="", collapse=" ")
  }
  est_nam = sapply(est_nam, simpleCap)
  est_nam[est_nam == "MipIC"] = "MIP"
  #
  sollll = as.data.frame(matrix(NA, nrow(sol)*length(est_nam), 8))
  for (j in 1:length(est_nam)) {
    sollll[seq(j, nrow(sollll), by=length(est_nam)), ] = sol[, (8*j-7):(8*j)]
  }
  
  soll = cbind.data.frame(rep(n, each=length(est_nam)), 
                          rep(p, each=length(est_nam)),
                          rep(est_nam, length(n)), sollll)
  type_nam = unlist(unique(lapply(strsplit(colnames(sol), "_"), `[[`, 2)))
  colnames(soll) <- c("n", "p", "Estimator", type_nam)
  
  #  compute F-scores from FPR and FNR
  if (ij==1) {
    tpB = 1 - soll$fnBeta
    fscB = tpB/(tpB+1/2*(soll$fpBeta+soll$fnBeta))
    tpP = 1 - soll$fnPhi 
    fscP = tpP/(tpP+1/2*(soll$fpPhi+soll$fnPhi))
  }
  
  # set up data frame
  df = soll
  df[[1]] <- as.character(df[[1]])
  df[[1]][-seq(1, length(df[[2]]), by=length(est_nam))] = ""
  # remove extra p
  df[[2]] <- as.character(df[[2]])
  df[[2]][-seq(1, length(df[[2]]), by=length(est_nam))] = ""

  if (ij == 1) {
    dfMed = df  
    dfMed[,4:ncol(dfMed)]= format(round(dfMed[,4:ncol(dfMed)], digits=ndig), nsmall=ndig)
  } else {
    dfMad = df
    dfMad[,4:ncol(dfMad)] = format(round(dfMad[,4:ncol(dfMad)], digits=ndig), nsmall=ndig)  
  }

}

dfMM = df
for (i in 1:nrow(df)){
  for(j in 4:ncol(df)){
    dfMM[i,j] = paste0(as.character(dfMed[i,j]), "(", as.character(dfMad[i,j]), ")")
  }
}
dfMM[,ncol(dfMM)] = gsub("[[:space:]]", "", dfMM[,ncol(dfMM)])
dfMM
dfMM = cbind.data.frame(dfMM[, 1:8], format(round(fscB, digits=ndig)), dfMM[, 9:10], format(round(fscP, digits=ndig)), dfMM[, 11])
colnames(dfMM)[c(9, 12:13)] = c("FsBeta", "FsPhi", "time")
dfMM

strCaption <- paste0("Simulation results.")
# set up xtable output
print(xtable(dfMM, digits = ndig, 
             align = "ccclcccccccccc",
             caption = strCaption), 
      size = "footnotesize\\renewcommand\\arraystretch{0.6} \n", 
      include.rownames = FALSE, 
      include.colnames = FALSE, 
      caption.placement = "top", 
      hline.after=NULL, 
      floating=TRUE, 
      sanitize.text.function = force, 
      add.to.row = list(pos = list(-1,
                                   2,
                                   nrow(df)),
                        command = c(paste("\\midrule \\midrule \n", 
                                          "n & p & Method & RMSPE & 
                                          $\\text{var}(\\hat{\\beta})$ & $\\text{bias}(\\hat{\\beta})^2$ &
                                          $\\text{FPR}(\\hat{\\beta})$ & $\\text{FNR}(\\hat{\\beta})$ & $\\text{Fscore}(\\hat{\\beta})$ &
                                          $\\text{FPR}(\\hat{\\phi})$ & $\\text{FNR}(\\hat{\\phi})$ & $\\text{Fscore}(\\hat{\\phi})$ &
                                          $\\text{Time}$ \\\\ \\midrule \n"
                        ),
                        paste("\n" 
                        ),
                        paste("\\bottomrule \n"  
                        )
                        )
      )
)

