setwd("C:/Users/Luca/OneDrive/Desktop/MIPresSFSOD")

fl = list.files()[grepl("OUT.csv", list.files())]

# sseeds = 2021
nn = c(50, 100, 150)
pp = c(50, 200)

# fll = fl[grepl(as.character(sseeds), fl)]


# Get file list
# file_list <- list.files()

# fl = list.files()
lfl = lapply(fl, function(x){
  strsplit(x, "-")
  })
tmp = matrix(0, length(fl), 6)
j = 1
for (pi in pp) {
  for (ni in nn) {
    for (ii in 1:length(fl)) {
      tmp1 = lfl[[ii]][[1]][1] == ni
      tmp2 = lfl[[ii]][[1]][2] == pi
      tmp[ii, j] = tmp1 && tmp2
    }
    j = j+1
  }
}
tmp
fl


for (i in 1:6) {
  nfl = fl[as.logical(tmp[, i])]
  # Read all csv files in the folder and create a list of dataframes
  ldf <- lapply(nfl, read.csv)
  # Combine each dataframe in the list into a single dataframe
  df.final <- do.call("rbind", ldf)
  namei = strsplit(nfl[1], "-")
  namei = namei[[1]][c(1:8, 10)]
  namei[8] = as.character(length(ldf)*as.numeric(namei[8]))
  namei = paste(namei, collapse = "-")
  if (i>3) {
    write.csv(df.final, paste0("merged/high/", namei), row.names = F)  
  } else{
    write.csv(df.final, paste0("merged/low/", namei), row.names = F)  
  }
  
}


